﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sport.Classes
{
    internal class Connect
    {
        public static Models.SportEntities1 modelbd;
    }
}
